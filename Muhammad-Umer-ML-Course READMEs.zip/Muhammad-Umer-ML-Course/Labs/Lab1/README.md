# Lab 1 — Introduction to Python for ML & Data Exploration

## Overview

This lab introduced the foundational tools used throughout the course: Python, NumPy, pandas, and Matplotlib. The central task was loading a real dataset, inspecting its structure, handling missing values, and producing basic visualizations to understand the distribution of features before any modeling took place.

## What I Did

I loaded a CSV dataset using pandas and used descriptive statistics to get a first look at the data. I identified columns with missing values and applied simple imputation strategies. I then used Matplotlib and Seaborn to create histograms, box plots, and a correlation heatmap to understand relationships between variables.

## What I Learned

This lab reinforced how much time goes into understanding data before any machine learning actually begins. The correlation heatmap in particular helped me see which features were likely to be predictive and which were largely redundant. I also got comfortable with the pandas workflow for slicing, filtering, and transforming DataFrames, which is a skill that carried through every subsequent lab.

## Challenges

Getting the visualizations to render cleanly inside the Jupyter Notebook took some adjustment. I also had to look up the correct syntax for multi-level column indexing in pandas, which behaves differently than basic Python dictionaries.

## Files

- `lab1_notebook.ipynb` — Full notebook with code, outputs, and commentary
