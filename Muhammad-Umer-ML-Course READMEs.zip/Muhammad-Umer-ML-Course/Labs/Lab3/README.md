# Lab 3 — Decision Trees and Model Evaluation

## Overview

This lab explored decision tree classifiers and introduced a more rigorous approach to model evaluation, including cross-validation, hyperparameter tuning, and the bias-variance tradeoff.

## What I Did

I trained a decision tree classifier and visualized the tree structure to understand how the model was splitting the feature space. I then used GridSearchCV to tune the max depth and minimum samples per leaf, comparing performance across different configurations. Finally I applied k-fold cross-validation to get a more reliable estimate of generalization error.

## What I Learned

Visualizing the decision tree made the model feel genuinely interpretable in a way that linear models do not. Seeing which features appeared near the root of the tree gave intuitive insight into which variables the model considered most informative. I also developed a clearer understanding of overfitting: a tree allowed to grow without constraints memorizes the training data but performs poorly on unseen examples.

## Challenges

GridSearchCV with a large parameter grid took noticeably longer to run than a single model fit. Learning to read the cross-validation results table and identify the best parameter combination without overfitting to the validation set required careful attention.

## Files

- `lab3_notebook.ipynb` — Decision tree training, visualization, and hyperparameter tuning
