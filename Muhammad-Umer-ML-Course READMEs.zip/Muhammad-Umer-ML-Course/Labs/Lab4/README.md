# Lab 4 — Neural Networks and Deep Learning Basics

## Overview

This lab introduced feedforward neural networks using TensorFlow and Keras. The goal was to build, train, and evaluate a simple multi-layer perceptron on a classification task and develop an intuition for how network architecture and training hyperparameters affect learning.

## What I Did

I constructed a sequential neural network with two hidden layers using ReLU activations and a softmax output layer for multi-class classification. I trained the model using the Adam optimizer and categorical cross-entropy loss, monitoring training and validation accuracy across epochs. I also experimented with dropout regularization to observe its effect on overfitting.

## What I Learned

This lab connected directly to my neuroscience coursework in a way that none of the previous labs had. Watching the loss curve decrease over epochs gave a concrete picture of gradient descent that the mathematical description alone had not fully conveyed. The effect of dropout was also striking: removing a fraction of neurons during training produced a model that generalized better, which maps conceptually onto the redundancy and robustness of biological neural circuits.

## Challenges

Choosing the right number of epochs without overfitting required watching the validation loss carefully. Early in training the validation loss tracked the training loss closely, but after a certain point it began to increase while training loss continued to fall — a clear visual signal of overfitting that I used to decide when to stop.

## Files

- `lab4_notebook.ipynb` — Neural network construction, training, and regularization experiments
