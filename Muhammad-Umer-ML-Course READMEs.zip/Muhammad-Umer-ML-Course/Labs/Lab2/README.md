# Lab 2 — Supervised Learning: Linear & Logistic Regression

## Overview

This lab introduced the two foundational supervised learning algorithms: linear regression for continuous output prediction and logistic regression for binary classification. Both were implemented using scikit-learn on cleaned datasets.

## What I Did

For linear regression, I trained a model to predict a continuous target variable and evaluated it using Mean Squared Error and R-squared. For logistic regression, I worked with a binary classification dataset, trained the model, and evaluated its performance using a confusion matrix, accuracy score, and classification report.

## What I Learned

The conceptual leap from linear to logistic regression — specifically the role of the sigmoid function in mapping a linear combination of features to a probability — was the key insight from this lab. I also learned how to split data into training and test sets properly and why doing so before any preprocessing steps is important to avoid data leakage.

## Challenges

Interpreting the coefficients in the logistic regression model was initially confusing because they represent log-odds rather than direct probabilities. Spending time converting a few coefficients manually helped solidify the intuition.

## Files

- `lab2_notebook.ipynb` — Full notebook with both regression experiments
