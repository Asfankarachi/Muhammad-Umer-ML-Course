# Assignment 2 — End-to-End ML Pipeline with Model Comparison

## Problem

This assignment required building a complete machine learning pipeline and systematically comparing the performance of multiple classification algorithms on the dataset prepared in Assignment 1. The objective was not only to identify the best-performing model but to understand why certain models performed better and what tradeoffs each approach involves.

## Approach and Methods

I wrapped the preprocessing steps from Assignment 1 into a scikit-learn Pipeline object to ensure that all transformations were applied consistently to both training and test data without leakage. I then trained and evaluated five classifiers:

1. Logistic Regression (baseline)
2. Decision Tree Classifier
3. Random Forest Classifier
4. Support Vector Machine (RBF kernel)
5. K-Nearest Neighbors

Each model was evaluated using stratified 5-fold cross-validation. Performance was measured using accuracy, precision, recall, F1-score, and ROC-AUC. For the two best-performing models, I ran GridSearchCV to fine-tune hyperparameters before a final evaluation on the held-out test set.

## Results

| Model | CV Accuracy | Test F1 | ROC-AUC |
|-------|-------------|---------|---------|
| Logistic Regression | 0.81 | 0.79 | 0.87 |
| Decision Tree | 0.76 | 0.74 | 0.78 |
| Random Forest | 0.87 | 0.85 | 0.92 |
| SVM (RBF) | 0.85 | 0.83 | 0.90 |
| KNN | 0.79 | 0.77 | 0.83 |

The Random Forest classifier achieved the best performance across all metrics after hyperparameter tuning. Its ensemble approach reduced the variance that caused the single Decision Tree to underperform, while remaining more interpretable than the SVM through feature importance scores.

## What the Results Mean

The gap between the Decision Tree and Random Forest results illustrated the bias-variance tradeoff in practice: a single tree overfit the training data, but averaging across many trees in the forest produced a much more stable and generalizable model. The feature importance output from the Random Forest also aligned well with the correlations identified during EDA, providing a useful sanity check that the model was learning meaningful patterns rather than noise.

## Files

- `assignment2_notebook.ipynb` — Full pipeline, model training, comparison, and analysis
