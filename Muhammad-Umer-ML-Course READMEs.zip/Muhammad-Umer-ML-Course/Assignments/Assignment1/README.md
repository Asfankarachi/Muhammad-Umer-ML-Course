# Assignment 1 — Exploratory Data Analysis & Feature Engineering

## Problem

The goal of this assignment was to take a raw, real-world dataset and prepare it for machine learning through a complete exploratory data analysis and feature engineering pipeline. The dataset contained demographic and clinical variables with a mix of data types, missing values, and skewed distributions.

## Approach and Methods

I began with a structural audit of the dataset: checking shape, data types, missing value counts, and the distribution of the target variable. I then used visual tools (histograms, box plots, and a correlation matrix) to identify patterns and potential issues before any transformation took place.

For feature engineering, I applied the following steps:

- **Missing value imputation:** Numerical columns were filled with the median; categorical columns were filled with the mode.
- **Encoding:** Nominal categorical variables were one-hot encoded. Ordinal variables were label-encoded to preserve rank information.
- **Scaling:** Continuous numerical features were standardized using StandardScaler to ensure that no single feature dominated distance-based calculations.
- **Feature creation:** I derived two interaction features based on domain reasoning and included them as candidate inputs for the modeling phase.

## Results and Interpretation

After preprocessing, the dataset was clean, fully encoded, and scaled. The correlation analysis revealed three features with strong linear relationships to the target, while two originally included features turned out to be near-zero variance columns that were dropped. The engineered interaction features showed moderate correlation with the target, suggesting they may add predictive value.

The final processed dataset was saved and is ready to be used as input for the modeling pipeline in Assignment 2.

## Files

- `assignment1_notebook.ipynb` — Full EDA, visualization, and feature engineering pipeline
