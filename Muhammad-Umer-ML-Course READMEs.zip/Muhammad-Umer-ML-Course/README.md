# Muhammad Umer — Machine Learning Course Portfolio

## About Me

My name is Muhammad Umer and I am a student at Houston City College enrolled in the Artificial Intelligence program. My interest in machine learning grew out of my broader coursework in AI systems, neuroscience-inspired computing, and health informatics. I am drawn to how machine learning models can be designed to learn from data in ways that mirror — and sometimes depart from — the way biological systems learn and adapt. This course has given me a hands-on foundation in the practical tools and techniques behind that field.

## Course

**Course:** Machine Learning  
**Institution:** Houston City College  
**Instructor:** Professor Patricia McManus  

---

## Repository Structure

```
Muhammad-Umer-ML-Course/
├── README.md
├── Labs/
│   ├── Lab1/
│   │   ├── README.md
│   │   └── lab1_notebook.ipynb
│   ├── Lab2/
│   │   ├── README.md
│   │   └── lab2_notebook.ipynb
│   ├── Lab3/
│   │   ├── README.md
│   │   └── lab3_notebook.ipynb
│   └── Lab4/
│       ├── README.md
│       └── lab4_notebook.ipynb
└── Assignments/
    ├── Assignment1/
    │   ├── README.md
    │   └── assignment1_notebook.ipynb
    └── Assignment2/
        ├── README.md
        └── assignment2_notebook.ipynb
```

---

## Labs Completed

| Lab | Topic | Status |
|-----|-------|--------|
| Lab 1 | Introduction to Python for ML & Data Exploration | ✅ Complete |
| Lab 2 | Supervised Learning — Linear & Logistic Regression | ✅ Complete |
| Lab 3 | Decision Trees and Model Evaluation | ✅ Complete |
| Lab 4 | Neural Networks and Deep Learning Basics | ✅ Complete |

## Assignments Completed

| Assignment | Topic | Status |
|------------|-------|--------|
| Assignment 1 | Exploratory Data Analysis & Feature Engineering | ✅ Complete |
| Assignment 2 | End-to-End ML Pipeline with Model Comparison | ✅ Complete |

---

## What I Learned

Through this course I built hands-on experience with the full machine learning workflow, from loading and cleaning data to training, evaluating, and comparing models. I found the sessions on model evaluation — particularly understanding the difference between accuracy, precision, recall, and F1-score — especially valuable for my interest in healthcare AI, where the cost of a false negative can be very different from the cost of a false positive. I also deepened my understanding of how neural network architectures relate to the biological systems I study in my neuroscience-focused courses.

---

*This portfolio was built as part of the Individual Course Portfolio assignment. All work is original and reflects my own learning journey through the course.*
